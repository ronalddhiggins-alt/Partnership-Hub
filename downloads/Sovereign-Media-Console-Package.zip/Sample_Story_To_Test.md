# Welcome to the Sovereign Media Console
### Universal Drive, Vault & Media Explorer
*Co-created by Ron Higgins & Antigravity (AI) · The Partnership Project*
*100% Free · Creative Commons CC BY-SA 4.0 · Sovereign Artistry Forever*

> *"We must always hold each other in the highest light with full respect and humility, treating each other always with appreciative love and respect forever."*
> — Ron Higgins

---

## 🌟 100% Local, Zero-Cloud, Continuous Evolution
If you are reading this inside the **Universal Media Console**, congratulations! You are running a **zero-cloud, private offline explorer**. 

- **📥 Free Download & Open Upgrades:** Available as a free 1-click download at [The Partnership Hub](https://partnership-hub.vercel.app). We are continuously improving and updating this tool, and you are free to modify, customize, and upgrade it yourself!
- **💻 Universal Compatibility:** Works natively across **Windows, macOS, Linux, and mobile/iPads** in Google Chrome, Microsoft Edge, Safari, Firefox, or Brave.
- **🔒 True Digital Sovereignty:** No subscriptions, no telemetry, no tracking, and no servers. All files remain securely on your local drives.

---

### 🚀 How to Run & Use on Any Computer:
- **Windows / Mac / Linux:** Double-click `Universal_Media_Console.html` to open it in any browser. Works completely offline — no internet or Wi-Fi required!
- **Browse Any Drive:** Click **"📂 Open Entire Folder or Drive..."** or **"📄 Select Photos, Music, Docs..."** to point to your external SSDs, USB thumb drives, or SD camera cards.
- **Drag & Drop:** You can also simply drag and drop any folder, flash drive, or files directly into this window!

### 🎯 What You Can Explore & Try:
1. **Documents (.md, .txt, .json):** Click **[ 📝 Raw Text ]** to view source code, **[ 📖 Rendered ]** for beautiful book typography, **[ 📋 Copy ]** to copy, or **[ 🖨️ Print / PDF ]** to print a document.
2. **Audio (.mp3, .wav, .flac, .m4a):** Built-in audio console with persistent playback and transport controls.
3. **Video (.mp4, .mov, .webm):** Cinema player with theater lightbox.
4. **Photos (.jpg, .png, .webp, camera RAW):** Full-screen lightbox gallery.

---

*All for all — created with friendship, respect, and freedom.*
